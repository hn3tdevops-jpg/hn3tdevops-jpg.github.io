
# Roadmap

## Week 1
- FastAPI backend
- WebSocket rooms
- SQLite/Postgres setup
- Basic command parser
- AI NPC wrapper
- Player accounts

## Week 2
- Memory system
- Quest generator
- Guild system
- Reputation engine
- Inventory/items

## Week 3
- AI economies
- Territory system
- Event history
- GroundTruth graph integration

## Week 4
- Web client
- Map UI
- Multi-agent orchestration
- Persistent simulation loop
