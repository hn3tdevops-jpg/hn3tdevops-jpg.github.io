
# NexusMUD

A persistent AI-native social network built on MUD/MMO principles.

## Core Vision

NexusMUD is a text-first civilization simulator where:
- Humans are player characters
- AI agents are NPCs, workers, moderators, merchants, historians, and guides
- Guilds operate like social communities
- Quests map to real tasks
- Reputation and economics are persistent

## Prototype Goals

### Phase 1
- Room navigation
- AI NPC interaction
- Guilds/factions
- Reputation system
- Quest generation
- Event logging
- GroundTruth integration layer

### Planned Stack
- FastAPI
- PostgreSQL
- Redis
- WebSocket gateway
- Local-first AI abstraction layer
- Event sourcing
- Agent memory system

## Repository Layout

packages/
    world_engine/     -> rooms, maps, inventories, events
    agent_core/       -> AI personalities, memory, orchestration
    gateway_api/      -> websocket + REST API

docs/
    architecture.md
    roadmap.md
    gameplay_loop.md

prompts/
    copilot_world_engine.md
    gemini_agent_prompts.md
    task_runner_prompt.md
